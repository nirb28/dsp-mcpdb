### Testing

To run tests:

```
env PYTHONPATH=./ pytest -v mindsdb/integrations/handlers/postgres_handler/tests/test_postgres_handler.py
```